package com.example.calculator;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Html;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private TextView input,view;
    private Button btn0,btn1,btn2,btn3,btn4,btn5,btn6,btn7,btn8,btn9;
    private Button btnPlus,btnMinus,btnMul,btnDivi;
    private Button btnDot,btnC;
    private Button btnEqual;

    private Button btnFact, btnSqrt;
    private Button btnSqr,btnQub,btnPower;

    private Button btnSine,btnCos,btnTan;

    private double val1,val2;
    private boolean isSum,isSub,isMul,isDivi,isPower;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        view = findViewById(R.id.view);
        input = findViewById(R.id.etInput);

        btn0 = findViewById(R.id.btn0);
        btn1 = findViewById(R.id.btn1);
        btn2 = findViewById(R.id.btn2);
        btn3 = findViewById(R.id.btn3);
        btn4 = findViewById(R.id.btn4);
        btn5 = findViewById(R.id.btn5);
        btn6 = findViewById(R.id.btn6);
        btn7 = findViewById(R.id.btn7);
        btn8 = findViewById(R.id.btn8);
        btn9 = findViewById(R.id.btn9);

        btnC = findViewById(R.id.btnC);

        btnPlus = findViewById(R.id.btnPlus);
        btnMinus = findViewById(R.id.btnMinus);
        btnMul = findViewById(R.id.btnMul);
        btnDivi = findViewById(R.id.btnDiv);

        btnDot = findViewById(R.id.btnDot);

        btnEqual = findViewById(R.id.btnEqual);

        btnFact = findViewById(R.id.btnFact);
        btnSqrt = findViewById(R.id.btnRoot);

        btnSqr = findViewById(R.id.btnSqr);
        btnQub = findViewById(R.id.btnQub);
        btnPower = findViewById(R.id.btnPower);

        btnSine = findViewById(R.id.btnSin);
        btnCos = findViewById(R.id.btnCos);
        btnTan = findViewById(R.id.btnTan);



        btn0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                input.setText(input.getText().toString()+"0");
            }
        });

        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                input.setText(input.getText().toString()+"1");
            }
        });

        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                input.setText(input.getText().toString()+"2");
            }
        });

        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                input.setText(input.getText().toString()+"3");
            }
        });

        btn4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                input.setText(input.getText().toString()+"4");
            }
        });

        btn5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                input.setText(input.getText().toString()+"5");
            }
        });

        btn6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                input.setText(input.getText().toString()+"6");
            }
        });

        btn7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                input.setText(input.getText().toString()+"7");
            }
        });

        btn8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                input.setText(input.getText().toString()+"8");
            }
        });

        btn9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                input.setText(input.getText().toString()+"9");
            }
        });

        btnDot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                input.setText(input.getText().toString()+".");
            }
        });

        btnC.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                input.setText("");
                view.setText("");

                val1 = 0;
                val2 = 0;

                isSum = false;
                isSub = false;
                isMul = false;
                isDivi = false;
                isPower = false;
            }
        });

        btnPlus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                val1 = Double.parseDouble(input.getText().toString());
                view.setText(view.getText().toString()+"" +input.getText().toString()+" + ");
                isSum = true;
                input.setText(null);
            }
        });

        btnMinus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                val1 = Double.parseDouble(input.getText().toString());
                view.setText(view.getText().toString()+" " +input.getText().toString()+"-");
                isSub = true;
                input.setText(null);
            }
        });

        btnMul.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                val1 = Double.parseDouble(input.getText().toString());
                view.setText(view.getText().toString()+" " +input.getText().toString()+"*");
                isMul = true;
                input.setText(null);
            }
        });

        btnDivi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                val1 = Double.parseDouble(input.getText().toString());
                view.setText(view.getText().toString()+" " +input.getText().toString()+"/");
                isDivi = true;
                input.setText(null);
            }
        });

        btnEqual.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                val2 = Double.parseDouble(input.getText().toString());

                try {
                    if (isSum) {
                        input.setText(String.valueOf(val1 + val2));
                        view.setText(view.getText().toString()+val2);
                    } else if (isSub) {
                        input.setText(String.valueOf(val1 - val2));
                        view.setText(view.getText().toString()+val2);
                    } else if (isMul) {
                        input.setText(String.valueOf(val1 * val2));
                        view.setText(view.getText().toString()+val2);
                    } else if (isDivi) {
                        input.setText(String.valueOf(val1 / val2));
                        view.setText(view.getText().toString()+val2);
                    }else if (isPower) {
                        input.setText(String.valueOf(Math.pow(val1,val2)));
                        view.setText(view.getText().toString()+val2);
                    }
                }catch (Exception e){
                    Toast.makeText(getApplicationContext(),e.toString(),Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnFact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try{
                    int total = 1;
                    for (int i = 1; i <= Integer.parseInt(input.getText().toString()); i++){
                        total *= i;
                    }
                    view.setText(input.getText().toString()+"!");
                    input.setText(String.valueOf(total));
                }catch (Exception e){
                    Toast.makeText(getApplicationContext(),e.toString(),Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnSqrt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try{
                    double sqrt = Math.sqrt(Double.parseDouble(input.getText().toString()));
                    input.setText(String.valueOf(sqrt));
                }catch (Exception e){
                    Toast.makeText(getApplicationContext(),e.toString(),Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnSqr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try{
                    double num = Double.parseDouble(input.getText().toString());
                    view.setText(input.getText().toString()+"^2");
                    input.setText(String.valueOf(num * num));
                }catch (Exception e){
                    Toast.makeText(getApplicationContext(),e.toString(),Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnQub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try{
                    double num = Double.parseDouble(input.getText().toString());
                    view.setText(input.getText().toString()+"^3");
                    input.setText(String.valueOf(num * num * num));
                }catch (Exception e){
                    Toast.makeText(getApplicationContext(),e.toString(),Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnPower.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try{
                    val1 = Double.parseDouble(input.getText().toString());
                    view.setText(input.getText().toString()+"^");
                    isPower = true;
                    input.setText(null);
                }catch (Exception e){
                    Toast.makeText(getApplicationContext(),e.toString(),Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnSine.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try{
                    val1 = Double.parseDouble(input.getText().toString());
                    view.setText("sin("+input.getText().toString()+")");
                    input.setText(String.valueOf(Math.sin(val1)));
                }catch (Exception e){
                    Toast.makeText(getApplicationContext(),e.toString(),Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnCos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try{
                    val1 = Double.parseDouble(input.getText().toString());
                    view.setText("cos("+input.getText().toString()+")");
                    input.setText(String.valueOf(Math.cos(val1)));
                }catch (Exception e){
                    Toast.makeText(getApplicationContext(),e.toString(),Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnTan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try{
                    val1 = Double.parseDouble(input.getText().toString());
                    view.setText("tan("+input.getText().toString()+")");
                    input.setText(String.valueOf(Math.sin(val1) / Math.cos(val1)));
                }catch (Exception e){
                    Toast.makeText(getApplicationContext(),e.toString(),Toast.LENGTH_SHORT).show();
                }
            }
        });
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle item selection
        switch (item.getItemId()) {
            case R.id.help:
                showHelp();
                return true;
            case R.id.info:
                startActivity(new Intent(this,AboutActivity.class));
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void showHelp() {
        AlertDialog.Builder alertDialog2 = new AlertDialog.Builder(this);

        alertDialog2.setCancelable(false);

        // Setting Dialog Title
        alertDialog2.setTitle("HELP");


        // Setting Dialog Message
        alertDialog2.setMessage("Hey! This is a simple Scientific Calculator.\n\n\n "+
                "NB: Please press some number before use ^2, ^3, sin, cos, tan, root and !.\n\n" +
                "For use ^ follow the pattern\n(Base number) ^ (power)\nEX: 2^10 = 1024"
        );


        // Setting Positive "Yes" Btn
        alertDialog2.setPositiveButton("DONE",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        // Write your code here to execute after dialog
                        dialog.cancel();
                    }
                });


        // Showing Alert Dialog
        alertDialog2.show();
    }
}
